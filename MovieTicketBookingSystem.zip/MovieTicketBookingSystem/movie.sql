/*
SQLyog Community Edition- MySQL GUI v8.04 
MySQL - 5.0.37-community-nt : Database - movie
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`movie` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `movie`;

/*Table structure for table `book` */

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `movie` varchar(30) default NULL,
  `theatre` varchar(30) default NULL,
  `date` varchar(10) default NULL,
  `time` varchar(10) default NULL,
  `tickets` varchar(100) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `book` */

insert  into `book`(`movie`,`theatre`,`date`,`time`,`tickets`) values ('Bhramastra','PVR','23.02.2023','07:00 AM','87'),('Bhramastra','PVR','23.02.2023','11:00 AM','100'),('Bhramastra','INOX','23.02.2023','07:00 AM','100'),('Bhramastra','INOX','23.02.2023','11:00 AM','100'),('RUSTOM','PVR','23.02.2023','11:00 AM','50'),('RUSTOM','PVR','23.02.2023','11:00 AM','50'),('RUSTOM','PVR','23.02.2023','11:00 AM','50'),('RUSTOM','PVR','23.02.2023','11:00 AM','50');

/*Table structure for table `register` */

DROP TABLE IF EXISTS `register`;

CREATE TABLE `register` (
  `name` varchar(30) default NULL,
  `password` varchar(30) default NULL,
  `phone` varchar(10) default NULL,
  `email` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `register` */

insert  into `register`(`name`,`password`,`phone`,`email`) values ('abc','123','abc','123');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
