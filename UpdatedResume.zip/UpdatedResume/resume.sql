/*
SQLyog Community Edition- MySQL GUI v8.04 
MySQL - 5.0.37-community-nt : Database - resume
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

CREATE DATABASE /*!32312 IF NOT EXISTS*/`resume` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `resume`;

/*Table structure for table `ed` */

DROP TABLE IF EXISTS `ed`;

CREATE TABLE `ed` (
  `sname` varchar(50) default '',
  `sagg` varchar(10) default '',
  `hname` varchar(50) default '',
  `hagg` varchar(10) default '',
  `guname` varchar(50) default '',
  `gcourse` varchar(30) default '',
  `guagg` varchar(10) default '',
  `pgname` varchar(50) default '',
  `pgcourse` varchar(30) default '',
  `pguagg` varchar(10) default ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `ed` */

insert  into `ed`(`sname`,`sagg`,`hname`,`hagg`,`guname`,`gcourse`,`guagg`,`pgname`,`pgcourse`,`pguagg`) values ('CPS','91.4','CPS','93','','','','','',''),('CPS','91.4','CPS','93','AITR','B.Tech','9.2','','',''),('CPS','91.4','CPS','93','AITR','B.Tech','9.2','','',''),('CPS','91.4','CPS','93','AITR','B.Tech','9.2','','','');

/*Table structure for table `entries` */

DROP TABLE IF EXISTS `entries`;

CREATE TABLE `entries` (
  `obj` varchar(1000) default NULL,
  `ach` varchar(1000) default NULL,
  `st` varchar(1000) default NULL,
  `exp` varchar(1000) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `entries` */

/*Table structure for table `pd` */

DROP TABLE IF EXISTS `pd`;

CREATE TABLE `pd` (
  `name` varchar(30) default NULL,
  `fname` varchar(30) default NULL,
  `mname` varchar(30) default NULL,
  `dob` date default NULL,
  `gender` varchar(20) default NULL,
  `num` varchar(10) default NULL,
  `email` varchar(100) default NULL,
  `li` varchar(100) default NULL,
  `add` varchar(100) default NULL,
  `city` varchar(20) default NULL,
  `pc` varchar(10) default NULL,
  `state` varchar(50) default NULL,
  `nation` varchar(20) default NULL,
  `hobbies` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `pd` */

insert  into `pd`(`name`,`fname`,`mname`,`dob`,`gender`,`num`,`email`,`li`,`add`,`city`,`pc`,`state`,`nation`,`hobbies`) values ('Mandvee Vatsa','Dharmendra Vatsa','Priti Vatsa','2003-01-20','Female','9098571782','mandveevatsa20@gmail.com','https://www.linkedin.com/in/mandvee-vatsa/','103-C Suryadev Nagar','Indore','452009','MP','Indian','Dance'),('Mandvee Vatsa','Dharmendra Vatsa','Priti Vatsa','2003-01-20','Female','9098571782','mandveevatsa20@gmail.com','https://www.linkedin.com/in/mandvee-vatsa/','103-C Suryadev Nagar','Indore','452009','MP','Indian','Dance'),('Mandvee Vatsa','Dharmendra Vatsa','Priti Vatsa','2003-01-20','Female','9098571782','mandveevatsa20@gmail.com','https://www.linkedin.com/in/mandvee-vatsa/','103-C Suryadev Nagar','Indore','452009','MP','Indian','Dance'),('Mandvee Vatsa','Dharmendra Vatsa','Priti Vatsa','2003-01-20','Female','9098571782','mandveevatsa20@gmail.com','https://www.linkedin.com/in/mandvee-vatsa/','103-C Suryadev Nagar','Indore','452009','MP','Indian','Dance');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
