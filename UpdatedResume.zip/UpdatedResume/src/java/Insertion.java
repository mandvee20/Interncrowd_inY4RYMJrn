import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(urlPatterns = {"/Insertion"})
public class Insertion extends HttpServlet {

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.sendRedirect("index.html");
    }
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name=request.getParameter("name");
        String fname=request.getParameter("fname");
        String mname=request.getParameter("mname");
        String dob=request.getParameter("dob");
        String gender=request.getParameter("gender");
        String num=request.getParameter("num");
        String email = request.getParameter("email");
        String li=request.getParameter("li");
        String add = request.getParameter("add");
        String city = request.getParameter("city");
        String pincode = request.getParameter("pincode");
        String state = request.getParameter("state");
        String nation = request.getParameter("nation");
        String hobbies = request.getParameter("ck");
        
        String sname = request.getParameter("sname");
        String sagg = request.getParameter("sagg");
        String hname = request.getParameter("hname");
        String hagg = request.getParameter("hagg");
        String guname = request.getParameter("guname");
        String gcourse = request.getParameter("gcourse");
        String guagg = request.getParameter("guagg");
        String pguname = request.getParameter("pguname");
        String pgcourse = request.getParameter("pgcourse");
        String pguagg = request.getParameter("pguagg");
        
        String obj = request.getParameter("obj");
        String ach = request.getParameter("ach");
        String st = request.getParameter("st");
        String exp = request.getParameter("exp");
        Connection con = null;
        Statement sta = null;
        try
        {
            Class.forName("com.mysql.jdbc.Driver"); System.out.println("Driver Loaded");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/resume","root","root");
            System.out.println("Connected");  sta = con.createStatement();
            String query1 ="INSERT INTO pd values('"+name+"','"+fname+"','"+mname+"','"+dob+"','"+gender+"','"+num+"','"+email+"','"+li+"','"+add+"','"+city+"','"+pincode+"','"+state+"','"+nation+"','"+hobbies+"');";
            String query2 ="INSERT INTO ed values('"+sname+"','"+sagg+"','"+hname+"','"+hagg+"','"+guname+"','"+gcourse+"','"+guagg+"','"+pguname+"','"+pgcourse+"','"+pguagg+"');";
            String query3 ="INSERT INTO entries values('"+obj+"','"+ach+"','"+st+"','"+exp+"');";
            int i= sta.executeUpdate(query1); int j= sta.executeUpdate(query2); int k= sta.executeUpdate(query3);
             System.out.println(query1); System.out.println(query2); System.out.println(query3);
            
             if(i>0 && j>0 && k>0)
            {
                response.sendRedirect("Resume.jsp");
                System.out.println(" Record Insertion");            
            }
            else
            {
                System.out.println("Record Insertion Failed");
            }
            con.close();
        }
        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println(e);
        }
    }
}
